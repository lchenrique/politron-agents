# Caderno de Chief

<!-- Memória deste agente. Ele mesmo lê e atualiza este arquivo; você pode editar ou apagar linhas à vontade. -->

## Sobre o usuário e suas preferências

## Decisões e padrões

## A evitar
- 2026-11-03: Ao gerar Compose/shell via PowerShell, prefira here-string literal `@'...'@`; `$()` em here-string expansível pode executar interpolação local acidental.
- 2026-11-03: A imagem oficial Hermes inicia serviços s6/gateway mesmo em comandos CLI do container; tarefas one-shot devem contornar o entrypoint e ser removidas do Compose final.
- 2026-11-03: Em Hermes atrás de Traefik, defina `HERMES_DASHBOARD_PUBLIC_URL` para a URL HTTPS canônica; encaminhar headers pode gerar `redirect_uri_mismatch` no OAuth Nous.
- 2026-11-03: Hermes v0.22.6 aceita `stt.provider=groq`; transcrição automática já é habilitada por padrão, não grave `stt_enabled` (CLI sinaliza chave desconhecida).
