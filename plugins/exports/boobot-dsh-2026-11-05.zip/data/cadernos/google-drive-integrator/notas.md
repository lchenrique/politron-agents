# Caderno de google-drive-integrator

<!-- Memória deste agente. Ele mesmo lê e atualiza este arquivo; você pode editar ou apagar linhas à vontade. -->

## Sobre o usuário e suas preferências

## Decisões e padrões

## A evitar

## 2026-11-03
- BubbleDesk Google Drive já implementa OAuth PKCE, Drive readonly, token refresh criptografado, listagem/sync e remoção da fonte; ausência confirmada: ação de desconectar/revogar grant da conta pelo app.
