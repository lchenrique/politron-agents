# Caderno de interface-designer

<!-- Memória deste agente. Ele mesmo lê e atualiza este arquivo; você pode editar ou apagar linhas à vontade. -->

## Sobre o usuário e suas preferências

## Decisões e padrões

## A evitar
